const displayZone = document.getElementById("display-zone");
const historyList = document.getElementById("history-list");
const previewDisplay = document.getElementById("preview-display");
const expressionDisplay = document.getElementById("expression-display");
const clearHistoryButtons = Array.from(document.querySelectorAll("[data-action='clear-history']"));
const operatorButtons = Array.from(document.querySelectorAll(".key-operator[data-action='operator']"));
const HISTORY_UNDO_HOLD_MS = 2000;

const state = {
  displayValue: "0",
  firstOperand: null,
  history: [],
  historyVisible: true,
  justEvaluated: false,
  lastClearedHistory: [],
  operator: null,
  waitingForSecondOperand: false,
};

let clearHistoryHoldTimer = null;
let suppressClearHistoryClick = false;

function formatNumber(value) {
  if (!Number.isFinite(value)) {
    return "Error";
  }

  if (Math.abs(value) > 0 && Math.abs(value) < 1e-12) {
    return value.toExponential(6).replace(/\.?0+e/, "e");
  }

  return Object.is(value, -0) ? "0" : String(value);
}

function parseDisplayValue() {
  return Number(state.displayValue);
}

function formatDisplayText(value) {
  if (value === "Error" || value.includes("e")) {
    return value;
  }

  const isNegative = value.startsWith("-");
  const unsignedValue = isNegative ? value.slice(1) : value;
  const [integerPart = "0", decimalPart] = unsignedValue.split(".");
  const formattedInteger = Number(integerPart || "0").toLocaleString("vi-VN");
  const sign = isNegative ? "-" : "";

  if (decimalPart === undefined) {
    return `${sign}${formattedInteger}`;
  }

  return `${sign}${formattedInteger},${decimalPart}`;
}

function getOperatorSymbol(operator) {
  const operatorMap = {
    add: "+",
    subtract: "\u2212",
    multiply: "\u00d7",
    divide: "\u00f7",
  };

  return operatorMap[operator] || "";
}

function calculate(firstOperand, secondOperand, operator) {
  switch (operator) {
    case "add":
      return firstOperand + secondOperand;
    case "subtract":
      return firstOperand - secondOperand;
    case "multiply":
      return firstOperand * secondOperand;
    case "divide":
      return secondOperand === 0 ? Number.NaN : firstOperand / secondOperand;
    default:
      return secondOperand;
  }
}

function getExpressionText() {
  if (state.operator && state.firstOperand !== null) {
    const firstText = formatDisplayText(String(state.firstOperand));
    const operatorText = getOperatorSymbol(state.operator);

    if (state.waitingForSecondOperand) {
      return `${firstText}${operatorText}`;
    }

    return `${firstText}${operatorText}${formatDisplayText(state.displayValue)}`;
  }

  return formatDisplayText(state.displayValue);
}

function getPreviewText() {
  if (!state.operator || state.firstOperand === null || state.waitingForSecondOperand) {
    return "";
  }

  const previewValue = formatNumber(calculate(state.firstOperand, parseDisplayValue(), state.operator));
  return previewValue === "Error" ? "Error" : formatDisplayText(previewValue);
}

function renderHistory() {
  historyList.innerHTML = state.history
    .slice(-5)
    .map((entry) => `<li class="history-item">${entry.expression}=<strong>${entry.result}</strong></li>`)
    .join("");

  displayZone.classList.toggle("is-history-hidden", !state.historyVisible);
}

function addHistoryEntry(firstOperand, operator, secondOperand, result) {
  state.history.push({
    expression: `${formatDisplayText(String(firstOperand))}${getOperatorSymbol(operator)}${formatDisplayText(String(secondOperand))}`,
    result: formatDisplayText(result),
  });
  state.history = state.history.slice(-12);
  renderHistory();
}

function updateDisplay() {
  expressionDisplay.textContent = getExpressionText();
  previewDisplay.textContent = getPreviewText();

  operatorButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.value === state.operator);
  });
}

function resetIfError() {
  if (state.displayValue !== "Error") {
    return;
  }

  state.displayValue = "0";
  state.firstOperand = null;
  state.operator = null;
  state.justEvaluated = false;
  state.waitingForSecondOperand = false;
}

function inputDigit(digit) {
  resetIfError();

  if (state.waitingForSecondOperand) {
    state.displayValue = digit;
    state.waitingForSecondOperand = false;
    updateDisplay();
    return;
  }

  if (state.justEvaluated && !state.operator) {
    state.displayValue = digit;
    state.justEvaluated = false;
    updateDisplay();
    return;
  }

  state.displayValue = state.displayValue === "0" ? digit : `${state.displayValue}${digit}`;
  state.justEvaluated = false;
  updateDisplay();
}

function inputDecimal() {
  resetIfError();

  if (state.waitingForSecondOperand) {
    state.displayValue = "0.";
    state.waitingForSecondOperand = false;
    updateDisplay();
    return;
  }

  if (state.justEvaluated && !state.operator) {
    state.displayValue = "0.";
    state.justEvaluated = false;
    updateDisplay();
    return;
  }

  if (!state.displayValue.includes(".")) {
    state.displayValue += ".";
    state.justEvaluated = false;
    updateDisplay();
  }
}

function clearCalculator() {
  state.displayValue = "0";
  state.firstOperand = null;
  state.operator = null;
  state.justEvaluated = false;
  state.waitingForSecondOperand = false;
  updateDisplay();
}

function clearHistory() {
  if (!state.history.length) {
    return;
  }

  state.lastClearedHistory = [...state.history];
  state.history = [];
  renderHistory();
}

function undoClearHistory() {
  if (!state.lastClearedHistory.length) {
    return;
  }

  state.history = [...state.lastClearedHistory];
  state.lastClearedHistory = [];
  renderHistory();
}

function toggleHistory() {
  state.historyVisible = !state.historyVisible;
  renderHistory();
}

function stopClearHistoryHold() {
  if (clearHistoryHoldTimer) {
    clearTimeout(clearHistoryHoldTimer);
    clearHistoryHoldTimer = null;
  }
}

function startClearHistoryHold(event) {
  if (event.pointerType === "mouse" && event.button !== 0) {
    return;
  }

  stopClearHistoryHold();
  suppressClearHistoryClick = false;

  clearHistoryHoldTimer = setTimeout(() => {
    suppressClearHistoryClick = true;
    undoClearHistory();
    clearHistoryHoldTimer = null;
  }, HISTORY_UNDO_HOLD_MS);
}

function backspace() {
  resetIfError();

  if (state.waitingForSecondOperand && state.firstOperand !== null) {
    state.displayValue = formatNumber(state.firstOperand);
    state.firstOperand = null;
    state.operator = null;
    state.justEvaluated = false;
    state.waitingForSecondOperand = false;
    updateDisplay();
    return;
  }

  if (state.displayValue.length === 1 || (state.displayValue.startsWith("-") && state.displayValue.length === 2)) {
    state.displayValue = "0";
    updateDisplay();
    return;
  }

  state.displayValue = state.displayValue.slice(0, -1);
  updateDisplay();
}

function toggleSign() {
  resetIfError();

  if (state.displayValue === "0") {
    return;
  }

  state.displayValue = formatNumber(-parseDisplayValue());
  state.justEvaluated = false;
  updateDisplay();
}

function convertPercent() {
  resetIfError();
  state.displayValue = formatNumber(parseDisplayValue() / 100);
  state.justEvaluated = false;
  updateDisplay();
}

function handleOperator(nextOperator) {
  resetIfError();

  const inputValue = parseDisplayValue();

  if (state.operator && !state.waitingForSecondOperand) {
    const result = formatNumber(calculate(state.firstOperand, inputValue, state.operator));
    state.displayValue = result;

    if (result === "Error") {
      state.firstOperand = null;
      state.operator = null;
      state.justEvaluated = false;
      state.waitingForSecondOperand = false;
      updateDisplay();
      return;
    }

    state.firstOperand = Number(result);
  } else {
    state.firstOperand = inputValue;
  }

  state.operator = nextOperator;
  state.justEvaluated = false;
  state.waitingForSecondOperand = true;
  updateDisplay();
}

function handleEquals() {
  resetIfError();

  if (!state.operator || state.firstOperand === null || state.waitingForSecondOperand) {
    return;
  }

  const secondOperand = parseDisplayValue();
  const result = formatNumber(calculate(state.firstOperand, secondOperand, state.operator));
  state.displayValue = result;

  if (result === "Error") {
    state.firstOperand = null;
    state.operator = null;
    state.justEvaluated = false;
    state.waitingForSecondOperand = false;
    updateDisplay();
    return;
  }

  addHistoryEntry(state.firstOperand, state.operator, secondOperand, result);
  state.firstOperand = null;
  state.operator = null;
  state.justEvaluated = true;
  state.waitingForSecondOperand = false;
  updateDisplay();
}

document.addEventListener("click", (event) => {
  const button = event.target.closest("button");

  if (!button) {
    return;
  }

  const { action, value } = button.dataset;

  switch (action) {
    case "digit":
      inputDigit(value);
      break;
    case "decimal":
      inputDecimal();
      break;
    case "clear":
      clearCalculator();
      break;
    case "toggle-sign":
      toggleSign();
      break;
    case "percent":
      convertPercent();
      break;
    case "backspace":
      backspace();
      break;
    case "operator":
      handleOperator(value);
      break;
    case "equals":
      handleEquals();
      break;
    case "clear-history":
      if (suppressClearHistoryClick) {
        suppressClearHistoryClick = false;
        break;
      }

      clearHistory();
      break;
    case "toggle-history":
      toggleHistory();
      break;
    default:
      break;
  }
});

clearHistoryButtons.forEach((button) => {
  button.addEventListener("pointerdown", startClearHistoryHold);
  button.addEventListener("pointerup", stopClearHistoryHold);
  button.addEventListener("pointerleave", stopClearHistoryHold);
  button.addEventListener("pointercancel", stopClearHistoryHold);
});

window.addEventListener("keydown", (event) => {
  const key = event.key;

  if (/^\d$/.test(key)) {
    inputDigit(key);
    return;
  }

  if (key === "." || key === ",") {
    inputDecimal();
    return;
  }

  if (key === "+" || key === "-" || key === "*" || key === "/") {
    const operatorMap = {
      "+": "add",
      "-": "subtract",
      "*": "multiply",
      "/": "divide",
    };

    handleOperator(operatorMap[key]);
    return;
  }

  if (key === "Backspace") {
    event.preventDefault();
    backspace();
    return;
  }

  if (key === "Enter" || key === "=") {
    event.preventDefault();
    handleEquals();
    return;
  }

  if (key === "Escape" || key.toLowerCase() === "c") {
    clearCalculator();
  }
});

updateDisplay();
renderHistory();
